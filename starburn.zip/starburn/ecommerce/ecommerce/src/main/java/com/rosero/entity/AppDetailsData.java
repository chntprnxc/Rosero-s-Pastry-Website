package com.rosero.entity;

public class AppDetailsData
{

}
