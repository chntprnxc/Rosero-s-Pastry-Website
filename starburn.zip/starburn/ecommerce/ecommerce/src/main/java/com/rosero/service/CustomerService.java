package com.rosero.service;

public interface CustomerService {

}
