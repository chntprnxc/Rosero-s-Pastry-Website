package com.rosero.entity;

public class CatagoryData {
}
