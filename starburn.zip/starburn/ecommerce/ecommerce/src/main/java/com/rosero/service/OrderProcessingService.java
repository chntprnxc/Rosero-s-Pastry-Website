package com.rosero.service;

import com.rosero.dto.CreateOrderRequest;

public interface OrderProcessingService {
    Long createOrder(CreateOrderRequest request);
}


