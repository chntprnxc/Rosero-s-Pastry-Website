package com.rosero.repository;

import com.rosero.entity.MenuData;
import org.springframework.data.repository.CrudRepository;

public interface MenuDataRepository extends CrudRepository<MenuData,Integer> {
}
