package com.rosero.entity;

public class AppDetailData {
}
