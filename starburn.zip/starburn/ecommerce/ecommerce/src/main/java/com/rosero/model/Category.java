package com.rosero.model;

public class Category {
    int id;
    String name;
    String description;
}
